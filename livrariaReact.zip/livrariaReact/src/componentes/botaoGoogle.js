import google from "../imagens/google.png"

const BotaoGoogle = (props) => {
    return ( 
    <>
        <button className="flex flex-row-reverse" onClick={props.onClick}>
            Entre com o google
            <img className="w-5" src={google} alt="logo" />
        </button>
    </> );
}
 
export default BotaoGoogle;