const BotaoPag = (props) => {
    return ( 
        <>
        <button onClick={props.acao} className="bg-[#1247AF] w-48 h-7"/>
          AAAAAAAAAA
        </>
     );
}
 
export default BotaoPag;