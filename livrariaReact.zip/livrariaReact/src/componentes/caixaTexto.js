const CaixaTexto = (props) => {
    return ( 
        <>
            <label className="text-black">{props.texto}</label>
            <input className=" border-2 border-solid boder-[#EEEEF0] rounded-lg w-[100%] h-[40px]" type={props.tipo} required={props.obrigatorio} placeholder={props.textoPlaceholder} onChange={props.onChange}/>
        </>
     );
}
 
export default CaixaTexto;