import CaixaTexto from "./caixaTexto";
import Logotipo from "../imagens/logo.png"
import BotaoGoogle from "./botaoGoogle";
import { useState } from "react";

const Formulario = ({ onClick }) => {
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')

  function MudancaInput(event) {
    setEmail(event.target.value)
    console.log(setEmail, setEmail)
  }

  function LoginGoogle() {
    window.location.href = "https://accounts.google.com/";
  }

  return (
    <>
      <div className="flex flex-col w-[60%] h-3/4 bg-white justify-center items-center rounded-3xl">
        <div className="w-60">
          <img src={Logotipo} alt="Logotipo"/>
        </div>
        <div className="pb-6 w-[80%]">
          <CaixaTexto texto='E-mail' value={email} tipo='email' textoPlaceholder='Digite o seu e-mail' />
        </div>
        <div className="pb-6 w-[80%]">
          <CaixaTexto texto='Senha' value={senha} tipo='password' textoPlaceholder='Digite a sua senha' />
        </div>
        <button className="bg-[#1247AF] text-cyan-50 w-[30%] h-[60px] rounded-2xl" onClick={() => (email, senha)}>
          Login
        </button>
        <button className="bg-[#DB4437] text-white w-[30%] h-[60px] rounded-2xl" onClick={LoginGoogle}>
          Login com Google
        </button>
      </div>
    </>
  );
}

export default Formulario;
