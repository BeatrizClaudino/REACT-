import React, { Component } from 'react';
import livros from "../imagens/bookImage 1.png"
import Formulario from '../componentes/formulario';

const Login = ({}) => {

        return (
        <>
            <div className='flex w-screen h-screen  bg-[#F5F4F7]'>
            <div className='p-0 w-[60%] hidden md:block'>
                <img className='h-screen' src={livros} />
            </div>
                <div className='flex justify-center items-center w-[100%]'>
                    <Formulario nomeBotao='Login' />
                </div>
            </div>
        </>
    );
}


export default Login;